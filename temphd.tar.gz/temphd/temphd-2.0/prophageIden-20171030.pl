#========================================================================
# Author: LXY
# Email:  sunqiang55@yahoo.com
# usage:  perl $in $out
#========================================================================

use strict;
use warnings;
use Cwd;

#Add database path
#phage database path
our $phage_prot_db = $ARGV[3];
#bacteria database path
#our $nt_Bacteria = $ARGV[4];
#glimer path
#our $glimmer_path = $ARGV[5];
#program path
our $program_path = $ARGV[4];

print "Enter prophageIden.pl\n";
print 'phage protein db ---> ',$phage_prot_db,"\n",
      'program path ---> ',$program_path,"\n";
#print "ttttttttttest\n$ARGV[0]\n";
#print "ttttttttttest\n$ARGV[1]\n";
#print "ttttttttttest\n$ARGV[2]\n";
#Input&Output folders
opendir(DIRin, "$ARGV[0]") or die "Cannot open:$!";
mkdir $ARGV[1];
opendir(DIRout, "$ARGV[1]") or die "Cannot open:$!";
#create temperary folder
our $temp=$ARGV[2];
system("mkdir -p $temp");

#the path where the program is
#our ($path_programm) = ($0=~/^(.*)prophageIden.*$/); 
#if($path_programm eq ""){ 
#$path_programm= getcwd; }
#else{
#	
#	}
#print $path_programm."\n";

#read the files in the folder one by one
while (our $name = readdir DIRin){
    next if $name =~ /^\./;
	  print 'name is-->',"$name\n";
	  print 'temp is-->',"$temp\n";
	  print 'prophage_prot_db is-->',"$phage_prot_db\n";
	  #orf prediction using prokka
	  system ("prokka --quiet --force --norrna --notrna --mincontiglen 110 --prefix $name.prok --outdir $temp $ARGV[0]/$name");
	  #orf prediction using glimmer
	  system ("long-orfs -z 11 -n -t 1.15 -l $ARGV[0]/$name $temp/$name.longorfs");
	  system ("extract -t $ARGV[0]/$name $temp/$name.longorfs > $temp/$name.train");
	  system ("build-icm -r $temp/$name.icm < $temp/$name.train");
	  system ("glimmer3 -z 11 -o 50 -g 110 -t 30 -l $ARGV[0]/$name $temp/$name.icm $temp/$name");
	  #change file format, keep the sequence in fasta file beofre the space
	  system ("perl $program_path/predict2formal.pl $temp/$name.predict $temp/$name.formal");
	  #merge results of glimmer and prokka
	  system ("python $program_path/prokka_glimmer_merge.py $temp/$name.formal $temp/$name.prok.gff $temp/$name.merge");
	  system ("multi-extract -t $ARGV[0]/$name $temp/$name.merge > $ARGV[1]/$name.cds");

	  #revert cds sequences to amino acid sequences
	  system ("perl $program_path/fa2std.pl $ARGV[1]/$name.cds $temp/$name.std");
	  system ("perl $program_path/cds2aa.v2.pl $temp/$name.std $ARGV[1]/$name.aa 11");
	  #blastp with phage protein database
	  print "Blasting...\n";
	  system ("blastp -query $ARGV[1]/$name.aa -db $phage_prot_db -num_alignments 5 -evalue 1e-10 -num_threads 16 -out $temp/$name.blastp");
	  #do statistics of the orfs which were aligned to phage protein databse
      system ("perl $program_path/high-positives.pl $temp/$name.blastp $temp/$name.txt");
}

closedir DIRin;
closedir DIRout;
