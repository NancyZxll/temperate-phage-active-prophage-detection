
#usage:  perl  *.pl  $Num[0](file)  $possibleseq[1](folder)  $matrix[2](folder) $database.fa[3](folder) $terminal len[4] (e.g. 20)  $outfile[5](output folder of detected phages)
use strict;                                                                                         
use warnings;
use Cwd;
use Bio::SeqIO;
use Bio::Seq;
use threads;
print "111\n";
#use Bio::AlignIO;
   #open ctg file
our $dir=getcwd();
our $thread;
our $numpath=$ARGV[0];
our $possiblepath=$ARGV[1];
our $matrixpath=$ARGV[2];
our $readspath=$ARGV[3];
our $N=$ARGV[4];
our $phagepath=$ARGV[5];
our $name=$ARGV[6];
#our $allphage_species=$ARGV[7];
our $input_ID=$ARGV[7];
our $program_path=$ARGV[8];
our $record_time=$ARGV[9];
our $phage_prot_db=$ARGV[10];
our $nt_Bacteria=$ARGV[11];
#our $glimmer_path=$ARGV[12];
our $program_path=$ARGV[12];
our $readsnum;
our $stringtemp;
our @reads1;
our @reads2;
our $title;
#store the paired-end reads
our @grepreads1;
our $grepreadsnum1=0;
our @grepreads2;
our $grepreadsnum2=0;
our @grepreads3;
our $grepreadsnum3=0;
our @grepreads4;
our $grepreadsnum4=0;



#blastn ref with reads database
#build database using all reads
system("makeblastdb -in $readspath/cat2.fa -dbtype nucl -parse_seqids -out $readspath/read");


print "The current pwd is: $dir\n";
print "The outputfile name is: $name\n";

our $i=0;
our $j=0;
our $findnum=0; #will be set 1 if grep one read successfully
our $phagecount=0;
our $iffind=0;
our $vertedfind=0;
our $findlast=0;

my $k=0;
my $h=0;


sub startposition{
	my ($bigseq,$smallseq)=@_;
	my $len;
	while($bigseq=~m/$smallseq/g){
		$len=length($smallseq);
		my $end=pos($bigseq);
		my $start=$end-$len+1;
		return($start);
		}
	}

sub endposition{
	my ($bigseq,$smallseq)=@_;
	my $len;
	while($bigseq=~m/$smallseq/g){
		$len=length($smallseq);
		my $end=pos($bigseq);
		return($end);
		}
	}

my $sta=&startposition("SSSSSSSSSSSSSSSDDDDDDDDDDDDDDDSSSSSSSSSdsfdgsJJJJJJJJJJJJJJJJJkokookLLLLLLLLLLLLLLL","dsfdgs");
my $end=&endposition("SSSSSSSSSSSSSSSDDDDDDDDDDDDDDDSSSSSSSSSdsfdgsJJJJJJJJJJJJJJJJJkokookLLLLLLLLLLLLLLL","dsfdgs");
print "The start: $sta\n";
print "The end: $end\n";

	
open(NUM,$numpath) or die "failed to open:$!";
while(<NUM>){
	print "222\n";
	print $_;
	my $realctg;
	my $ctg;
	my $phgnum;
	my $line=$_;
	if(/contig/){				
	my @temp = split(/_/,$_);
	$ctg=$temp[0];
	$phgnum=$temp[1];
	print "contig: $ctg\n";
	print "phgnum: $phgnum\n";
	if ($phgnum==0){
		&allcontigthread($ctg);
		}
	else {
		for ($j=1;$j<=$phgnum;$j++){
			&partcontigthread($j,$ctg);
			}		
		}
	}	
	}

close(NUM);

	foreach $thread(threads->list(threads::all)){
		$thread->join();
		print scalar(threads->list()),"\t$j\t",localtime(time),"\n";
		}



sub allcontigthread(){
		my ($ctg)=@_;
		my @ctgtemp=split(/>/,$ctg);
		my $realctg=$ctgtemp[1];
		my $section=$realctg;
		print "This is allcontig\n";
		print "The realctg is $realctg\n";
		my $seqpath=$possiblepath."/".$realctg.".fa";
		my $matrixnamepath=$matrixpath."/".$realctg.".txt";
		my $phagenamepath=$phagepath."/".$realctg;
		my $tempdir=$possiblepath."/".$realctg."temp";
		print "seqpath is $seqpath\n";
		print "matrixnamepath is $matrixnamepath\n";
		open(DATA1,"<$seqpath");
		my @text=<DATA1>;
		chomp(@text);
		my $string=join " ",@text;
		my $seqlen=length($string);
		close(DATA1);
		$iffind=0;
		&allcontiggrep($string,$seqlen,$phagenamepath,$realctg,$section,$seqpath);
		if($iffind==0){
		&partcontiggrep($string,$seqlen,$phagenamepath,$matrixnamepath,$realctg,$section,$seqpath);
			}
	}

sub partcontigthread(){
		my ($j,$ctg)=@_;
		my $section=$ctg."_".$j;
		my $seqpath=$possiblepath."/".$ctg."_".$j.".fa";
	  print "This is partcontig\n";
	  my $matrixnamepath=$matrixpath."/".$ctg."_".$j.".txt";
		my $phagenamepath=$phagepath."/".$ctg."_".$j;
		my $tempdir=$possiblepath."/".$ctg."temp";
		print "seqpath is $seqpath\n";
		print "matrixnamepath is $matrixnamepath\n";
		open(DATA1,"<$seqpath");
		my @text=<DATA1>;
		chomp(@text);
		my $string=join " ",@text;
		my $seqlen=length($string);
		close(DATA1);
	 	&partcontiggrep($string,$seqlen,$phagenamepath,$matrixnamepath,$ctg,$section,$seqpath);
	 		}


sub allcontiggrep{
	 my ($string,$seqlen,$phagenamepath,$ctg,$section)=@_;
	 $stringtemp=$string;
	 $vertedfind=0;
	 $findlast=0;
	 print "Verted greping...\n";
	 my $tempseq=substr($string,0,length($string)); #cut the repeats at the two ends
	 my $checkseq=substr($string,length($string)-10000,9999);
	 &grepall("all",$tempseq,$stringtemp,$phagenamepath,$ctg,$section,0,0,15);
	 if($findlast==1) {$iffind=1;}
 #catch reads in the reverse direction if no one found in the forward direction. 
	}
	
	
	

sub partcontiggrep{
	my ($string,$seqlen,$phagenamepath,$matrixnamepath,$ctg,$section)=@_;
	$stringtemp=$string;
	open(DATA4,"<$matrixnamepath");#open the file storing matrix
	system("mkdir -p $dir/$input_ID.Result");
	system("rm -rf $dir/$input_ID.Result/$section") if(-e "$dir/$input_ID.Result/$section");	#delete the original folder
while(<DATA4>){
	chomp;
	$title=$_;
	my @temp=split(/\s+/,$title);
	my $repeatlen=$temp[0];
		print "repeatlen: $repeatlen\n";
	my $start1=$temp[1];
	my $start2=$temp[2];
	my $mysta;
	my $myend;
	my $mystarevcom;
	my $myendrevcom;
	my $tt;
	print "@temp\n";
	$vertedfind=0;
	$findlast=0;
	
	my $repeat1=substr($string,$start1,$repeatlen);
	my $repeat2=substr($string,$start2,$repeatlen);
	if($temp[3]){
#
	 my $tempseq1=substr($string,$start1,$start2-$start1); #cut the repeats at the both ends
	 my $checkseqfor1=substr($string,$start1-5000,10000);
	 my $checkseqback1=substr($string,$start2-5000,10000);#sequence used for checking
	 my $checkseq1=$checkseqfor1.$checkseqback1;
	 print "temp[3]=1\n";
	 #print "$section:\n$checkseq1\n";
	 &grep1(1,$tempseq1,$checkseq1,$stringtemp,$phagenamepath,$ctg,$section,$start1,$start2,$repeatlen,$repeat1,$repeat2);
	 if($findlast==1) {last;}
		
		}
		
		
if($temp[3]==0){
	 our $tempseq5=substr($string,$start1,$start2-$start1); #cut the repeats at the both ends
	 my $checkseqfor2=substr($string,$start1-5000,10000);#sequence used for checking
	 my $checkseqback2=substr($string,$start2-5000,10000);#sequence used for checking
	 my $checkseq2=$checkseqfor2.$checkseqback2;
	 print "Verted greping...\n";
	 #print "$section:\n$checkseq2\n";
	 &grep1(0,$tempseq5,$checkseq2,$stringtemp,$phagenamepath,$ctg,$section,$start1,$start2,$repeatlen,$repeat1,$repeat2);
	 if($findlast==1) {last;}
				}
	
	}
	
	
	
	if($findnum==0){
	#	print "In $ARGV[0], found 0 prophage!\n";
		}
	
	close(DATA4);
	}
   

sub revcom{
	my ($a)=@_;
	my $recom=reverse $a;
  $recom=~tr/ACGTacgt/TGCAtgca/;
	return ($recom);
	}

sub grepall{
	 my ($case,$tempseq1,$stringtemp,$phagenamepath,$ctg,$section,$start1,$start2,$repeatlen)=@_;
	 my $i=0;
	 my $j=0;
	 my $position1;
	 my $position2;
	 my $dist;
	 my $find=0;
	 my $read1temp;
	 my $read2temp;
	 my $read1temprevcom;
	 my $read2temprevcom;
	 my @temp;
	 my @temp1;
	 my @tempid1;
	 my @temp2;
	 my @tempid2;
	 my $id;
	 my @idtemp;
	 my $flag; #1 for positive, 2 for negative
	 my @hit;
	 my @cohit;
	 my $hitnum=0;
	 my $cohitnum=0;
	 my @align1;
	 my @align2;
	 my $alignnum1=0;
	 my $alignnum2=0;
	 my $refseq;
	 my $p1;
	 my $p2;
	 my $t;
	 my $forrev;
	 my $hitnumtemp;
	 my $left;
	 my $right;
	 my $leftcondition;
	 my $rightcondition;
	 my $longleftcondition;
	 my $longrightcondition;
	 my $loopnum=0;
	 my $islong=0;
	 my $allphages;
	 my $size;
	 my @firstlinearray;
	 
	 
	 print "=================contig is: $ctg==============\n";
	 print "=================section is: $section==============\n";
	 system("mkdir -p $dir/$input_ID.Result");
   system("mkdir -p $dir/$input_ID.Result/$section");
	 open(RESULT,">$dir/$input_ID.Result/$section/result.txt");
	 print RESULT "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n";
	 my $mysta= substr($tempseq1,0,$N);     #get the sequence header
	 my $myend= substr($tempseq1,length($tempseq1)-$N,$N);  #get the sequence tail
	 my $len=length($tempseq1);
	 $refseq=$myend.$mysta;
	 print "The N is $N\n";
	 print "The length is $len\n";
	 #my $mystarevcom=revcom($mysta);
	 #my $myendrevcom=revcom($myend);
	 print RESULT "If case $case, mysta is: $mysta myend is: $myend\n";
	 #print RESULT "mystarevcom is: $mystarevcom myendrevcom is: $myendrevcom\n";
	 
	 open(REF,">$dir/$input_ID.Result/$section/ref.fa");	
	 open(COHIT,">$dir/$input_ID.Result/$section/cohit.fa");	
	 print REF ">ref.fa\n";
	 print REF "$refseq";



	 system("blastn -query $dir/$input_ID.Result/$section/ref.fa -db $readspath/read -out $dir/$input_ID.Result/$section/ref.table -num_alignments 30000 -num_threads 10 -outfmt \"7 qseqid pident slen length mismatch gapopen qstart qend sstart send sseqid\"");
	 system("blastn -query $dir/$input_ID.Result/$section/ref.fa -db $readspath/read -out $dir/$input_ID.Result/$section/ref_all.table -num_alignments 30000 -num_threads 10");
	 system("perl $program_path/handleiden.pl $dir/$input_ID.Result/$section/ref.table $dir/$input_ID.Result/$section/ref99.table 1");
	 close(REF);
	 

	 open(TABLE,"<$dir/$input_ID.Result/$section/ref99.table");
	 open(GRE,">>$dir/$input_ID.Result/$section/grep.txt");
	 while(<TABLE>){
	 	chomp;
	 	print RESULT "The line is: $_ ";
	 	@temp=split(/\s+/,$_);
	 	$p1=$temp[6];
	 	$p2=$temp[7];

	 	if($p1>$p2){
	 		$t=$p2;
	 		$p2=$p1;
	 		$p1=$t;
	 		}
	 	@idtemp=split(/&/,$temp[10]);
	 	$id=$idtemp[0];
	 	$forrev=$idtemp[1];
	 	$hit[$hitnum][0]=$id;
	 	$hit[$hitnum][1]=$forrev;
	 	$hit[$hitnum][2]=$p1;
	 	$hit[$hitnum][3]=$p2;
	 	
	 	print RESULT "!!!  $hit[$hitnum][0]  $hit[$hitnum][2]  $hit[$hitnum][3]\n";
		$hitnum++;
	 	}
	 	
		print RESULT "hitnum is $hitnum\n";
		print RESULT "...........\n";
		for($i=0;$i<$hitnum;$i++){
			print RESULT "the $i th run\n";
			for($j=$i+1;$j<$hitnum;$j++){

				
			if($hit[$i][0] eq $hit[$j][0]){
				
				$left=&min($hit[$i][2],$hit[$j][2]);
				$right=&max($hit[$i][3],$hit[$j][3]);
				$hit[$i][2]=$left;
				$hit[$j][2]=$left;
				$hit[$i][3]=$right;
				$hit[$j][3]=$right;
				

				
				}

				}
			}
		for($i=0;$i<$hitnum;$i++){
			print COHIT "$hit[$i][0]\t$hit[$i][1]\t$hit[$i][2]\t$hit[$i][3]\n";
			
			}
			
			
		print RESULT "hitnum is $hitnum\n";
		
		$leftcondition=$N-30;
		$rightcondition=$N+$repeatlen+30;
		$longleftcondition=$N-70;
		$longrightcondition=$N+$repeatlen+70;

		for($i=0;$i<$hitnum;$i++){
			if($hit[$i][2]<$leftcondition and $hit[$i][3]>$rightcondition){
				#print GRETEMP "all\n";
				print GRE "$hit[$i][0] $hit[$i][2] $hit[$i][3]\n";
				$find=1;
				$loopnum++;
				}

			if($hit[$i][2]<$longleftcondition and $hit[$i][3]>$longrightcondition){
				$islong=1;
				}
			
			}
	
	
	
	 close(TABLE);
	 close(GRE);
	 close(COHIT);
	 
	 	if(($find==1 and $loopnum>2) or ($find==1 and $islong==1 and $loopnum>1)){
	 		      my $prophageseq1=$tempseq1;
          	my $phagelength1=length($prophageseq1);
          	
            system("rm -rf $dir/$input_ID.Result/$section/check") if(-e "$dir/$input_ID.Result/$section/check");	#delete the original folder
            system("rm -rf $dir/$input_ID.Result/$section/check/in") if(-e "$dir/$input_ID.Result/$section/check/in");	#delete the original folder
            system("rm -rf $dir/$input_ID.Result/$section/check/out") if(-e "$dir/$input_ID.Result/$section/check/out");	#delete the original folder
            system("rm -rf $dir/$input_ID.Result/$section/check/temp") if(-e "$dir/$input_ID.Result/$section/check/temp");	#delete the original folder
            system("mkdir -p $dir/$input_ID.Result/$section/check");
            system("mkdir -p $dir/$input_ID.Result/$section/check/in");
            system("mkdir -p $dir/$input_ID.Result/$section/check/out");
            system("mkdir -p $dir/$input_ID.Result/$section/check/temp");
           
            open(CHE,">$dir/$input_ID.Result/$section/check/phage.fa");
            print CHE ">$ctg  length=$phagelength1   numreads\n";
            print CHE "$prophageseq1";
            close(CHE);
            system("cp $dir/$input_ID.Result/$section/check/phage.fa $dir/$input_ID.Result/$section/check/in/phage.fa");
            system("perl $program_path/prophageIden-20171030.pl $dir/$input_ID.Result/$section/check/in $dir/$input_ID.Result/$section/check/out $dir/$input_ID.Result/$section/check/temp $phage_prot_db $program_path");	            
           # system("perl $program_path/prophageIden-20171030.pl $dir/$input_ID.Result/$section/check/in $dir/$input_ID.Result/$section/check/out $dir/$input_ID.Result/$section/check/temp");
						system("python $program_path/blast+2tab-nn+e+2covery.py $dir/$input_ID.Result/$section/check/temp/phage.fa.blastp $dir/$input_ID.Result/$section/check/temp/phage.fa.table 1");
						system("perl $program_path/removefirstline.pl $dir/$input_ID.Result/$section/check/temp/phage.fa.table $dir/$input_ID.Result/$section/check/temp/phage.table");
						system("perl $program_path/GetPosProtein.pl $dir/$input_ID.Result/$section/check/temp/phage.table $dir/$input_ID.Result/$section/check/temp/Possible2");
            
						#system("rm -rf check/in");
						#system("rm -rf check/out");
						#system("rm -rf check/temp");
						#system("rm -rf check");
	 		
	 		}
	 	close(RESULT);
	 	}

sub grep1{
	 my ($case,$tempseq1,$checkseq,$stringtemp,$phagenamepath,$ctg,$section,$start1,$start2,$repeatlen,$repeat1,$repeat2)=@_;
	 my $i=0;
	 my $j=0;
	 my $position1;
	 my $position2;
	 my $dist;
	 my $find=0;
	 my $read1temp;
	 my $read2temp;
	 my $read1temprevcom;
	 my $read2temprevcom;
	 my @temp;
	 my @temp1;
	 my @tempid1;
	 my @temp2;
	 my @tempid2;
	 my $id;
	 my @idtemp;
	 my $flag; #1 for positive, and 2 for negative
	 my @hit;
	 my @cohit;
	 my $hitnum=0;
	 my $cohitnum=0;
	 my @align1;
	 my @align2;
	 my $alignnum1=0;
	 my $alignnum2=0;
	 my $refseq;
	 my $p1;
	 my $p2;
	 my $t;
	 my $forrev;
	 my $hitnumtemp;
	 my $left;
	 my $right;
	 my $leftcondition;
	 my $rightcondition;
	 my $longleftcondition;
	 my $longrightcondition;
	 my $loopnum=0;
	 my $islong=0;
	 my $allphages;
	 my $size;

 
   system("mkdir -p $dir/$input_ID.Result/$section");
   
	 print ("^^^^^^^^^^^^^^^section is:$section\n");
	 open(CCC,">$dir/$input_ID.Result/$section/checkcontigseq.fa");
	#print "$dir/$input_ID.Result/$section/checkcontigseq.fa\n";
	 print CCC "$checkseq\n";
#	 close(CCC);
	 print "$ctg\n";

	 open(RESULT,">$dir/$input_ID.Result/$section/result.txt");
	 open(GRETEMP,">$dir/$input_ID.Result/$section/greptemp.txt");
	 print RESULT "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n";
	 my $mysta= substr($tempseq1,0,$N);     #get the sequence header
	 my $myend= substr($tempseq1,length($tempseq1)-$N,$N);  #get the sequence tail
	 my $len=length($tempseq1);
	 $refseq=$myend.$mysta;
	 print "The N is $N\n";
	 print "The length is $len\n";
	 #my $mystarevcom=revcom($mysta);
	 #my $myendrevcom=revcom($myend);
	 print RESULT "If case $case, mysta is: $mysta myend is: $myend\n";
	 #print RESULT "mystarevcom is: $mystarevcom myendrevcom is: $myendrevcom\n";
	 
	 open(REF,">$dir/$input_ID.Result/$section/ref.fa");	
	 open(COHIT,">$dir/$input_ID.Result/$section/cohit.fa");	
	 print REF ">ref.fa\n";
	 print REF "$refseq";
	 print RESULT "checkcontigseq.fa: $dir/$input_ID.Result/$section/checkcontigseq.fa\n";
	 print "ref.fa: $dir/$input_ID.Result/$section/ref.fa\n";
	 system("blastn -query $dir/$input_ID.Result/$section/ref.fa -db $readspath/read -out $dir/$input_ID.Result/$section/ref.table -num_alignments 30000 -num_threads 10 -outfmt \"7 qseqid pident slen length mismatch gapopen qstart qend sstart send sseqid\"");
	 system("blastn -query $dir/$input_ID.Result/$section/ref.fa -db $readspath/read -out $dir/$input_ID.Result/$section/ref_all.table -num_alignments 30000 -num_threads 10");
	 system("perl $program_path/handleiden.pl $dir/$input_ID.Result/$section/ref.table $dir/$input_ID.Result/$section/ref99.table 0");
	 close(REF);
	 
	 system("blastn -query $dir/$input_ID.Result/$section/checkcontigseq.fa -db $readspath/read -out $dir/$input_ID.Result/$section/contig.table -num_alignments 200000 -num_threads 10 -outfmt \"7 qseqid pident slen length mismatch gapopen qstart qend sstart send sseqid\"");
	 system("perl $program_path/handleidencon.pl $dir/$input_ID.Result/$section/contig.table $dir/$input_ID.Result/$section/contig97.table");

	 open(TABLE,"<$dir/$input_ID.Result/$section/ref99.table");


	 while(<TABLE>){
	 	chomp;
	 	print RESULT "The line is: $_ ";
	 	@temp=split(/\s+/,$_);
	 	$p1=$temp[6];
	 	$p2=$temp[7];

	 	if($p1>$p2){
	 		$t=$p2;
	 		$p2=$p1;
	 		$p1=$t;
	 		}
	 	@idtemp=split(/&/,$temp[10]);
	 	$id=$idtemp[0];
	 	$forrev=$idtemp[1];
	 	$hit[$hitnum][0]=$id;
	 	$hit[$hitnum][1]=$forrev;
	 	$hit[$hitnum][2]=$p1;
	 	$hit[$hitnum][3]=$p2;
	 	print RESULT "!!!  $hit[$hitnum][0]  $hit[$hitnum][2]  $hit[$hitnum][3]\n";
		$hitnum++;
	 	}
	 	
		print RESULT "hitnum is $hitnum\n";
		print RESULT "...........\n";
		for($i=0;$i<$hitnum;$i++){
			print RESULT "The $i th run\n";
			for($j=$i+1;$j<$hitnum;$j++){

				
			if($hit[$i][0] eq $hit[$j][0]){
				$left=&min($hit[$i][2],$hit[$j][2]);
				$right=&max($hit[$i][3],$hit[$j][3]);
				$hit[$i][2]=$left;
				$hit[$j][2]=$left;
				$hit[$i][3]=$right;
				$hit[$j][3]=$right;
				

				
				}

				}
			}
		for($i=0;$i<$hitnum;$i++){
			print COHIT "$hit[$i][0]\t$hit[$i][1]\t$hit[$i][2]\t$hit[$i][3]\n";
			
			}
			
			
		print RESULT "hitnum is $hitnum\n";
		
		$leftcondition=$N-30;
		$rightcondition=$N+$repeatlen+30;
		$longleftcondition=$N-70;
		$longrightcondition=$N+$repeatlen+70;

		for($i=0;$i<$hitnum;$i++){
			if($hit[$i][2]<$leftcondition and $hit[$i][3]>$rightcondition){
				#print GRETEMP "notall\n";
				print GRETEMP "$hit[$i][0] $hit[$i][1] $hit[$i][2] $hit[$i][3]\n";
				$find=1;
				$loopnum++;
				}

			
			}
	
	
	
	 close(TABLE);
	 close(GRETEMP);
	 close(COHIT);
	 

	 system("perl $program_path/handlegrep.pl $dir/$input_ID.Result/$section/greptemp.txt $dir/$input_ID.Result/$section/contig97.table $dir/$input_ID.Result/$section/greptemp1.txt $dir/$input_ID.Result/$section/grep.txt");	 
	 

	 
	 my $filename1="$dir/$input_ID.Result/$section/grep.txt";
	 	if(-s $filename1){
	 		      my $prophageseq1=$tempseq1;
          	my $phagelength1=length($prophageseq1);
          	
            system("rm -rf $dir/$input_ID.Result/$section/check") if(-e "$dir/$input_ID.Result/$section/check");	#delete the original folder
            system("rm -rf $dir/$input_ID.Result/$section/check/in") if(-e "$dir/$input_ID.Result/$section/check/in");	#delete the original folder
            system("rm -rf $dir/$input_ID.Result/$section/check/out") if(-e "$dir/$input_ID.Result/$section/check/out");	#delete the original folder
            system("rm -rf $dir/$input_ID.Result/$section/check/temp") if(-e "$dir/$input_ID.Result/$section/check/temp");	#delete the original folder
            system("mkdir -p $dir/$input_ID.Result/$section/check");
            system("mkdir -p $dir/$input_ID.Result/$section/check/in");
            system("mkdir -p $dir/$input_ID.Result/$section/check/out");
            system("mkdir -p $dir/$input_ID.Result/$section/check/temp");
           
            open(CHE,">$dir/$input_ID.Result/$section/check/phage.fa");
            print CHE ">$ctg  length=$phagelength1   numreads\n";
            print CHE "$prophageseq1";
            close(CHE);
            system("cp $dir/$input_ID.Result/$section/check/phage.fa $dir/$input_ID.Result/$section/check/in/phage.fa");
            system("perl $program_path/prophageIden-20171030.pl $dir/$input_ID.Result/$section/check/in $dir/$input_ID.Result/$section/check/out $dir/$input_ID.Result/$section/check/temp $phage_prot_db $program_path");            
            #system("perl $program_path/prophageIden-20171030.pl $dir/$input_ID.Result/$section/check/in $dir/$input_ID.Result/$section/check/out $dir/$input_ID.Result/$section/check/temp");
						system("python $program_path/blast+2tab-nn+e+2covery.py $dir/$input_ID.Result/$section/check/temp/phage.fa.blastp $dir/$input_ID.Result/$section/check/temp/phage.fa.table 1");
						system("perl $program_path/removefirstline.pl $dir/$input_ID.Result/$section/check/temp/phage.fa.table $dir/$input_ID.Result/$section/check/temp/phage.table");
						system("perl $program_path/GetPosProtein.pl $dir/$input_ID.Result/$section/check/temp/phage.table $dir/$input_ID.Result/$section/check/temp/Possible2");
            
            my $checkpath="$dir/$input_ID.Result/$section/check/temp/Possible2";
            if(-s $checkpath){
            $phagecount++;
            $phagenamepath=$phagenamepath."_$start1\_$start2\_newactiveprophage2_$phagecount.fa";
            $size=$start2-$start1;
            $allphages="allphages/"."$input_ID\_$name\_$record_time\_$size\_$phagecount\_p.fa";#allphage_species
            print "allphagepath: $allphages";
            
    				print "It is a real phage!\n";   print RESULT "It is a real phage!\n";
            print "The prophageseq1 is: \n";  print RESULT "The prophageseq1 is: \n";
            print "$phagenamepath\n$prophageseq1\n";   print RESULT "$phagenamepath\n$prophageseq1\n";
            print "The length of prophageseq1 $name is: $phagelength1\n";  print RESULT "The length of prophageseq1 $name is: $phagelength1\n";
 
            open(OUT,">$phagenamepath");#write the phage sequence
            open(ALL,">$allphages");
            print OUT "$dir\n";
            print OUT ">$ctg"."_phage2_".$phagecount."\n";  
            print OUT "repeat1: $repeat1   repeat2: $repeat2\n";
            print OUT "$prophageseq1";  
            print ALL "$dir\n";
            print ALL ">$ctg"."_phage2_".$phagecount."\n";  
            print ALL "repeat1: $repeat1   repeat2: $repeat2\n";
            print ALL "$prophageseq1";  
            $vertedfind=1;
            $findlast=1;
            close(OUT);
            close(ALL);
            }
            
						#system("rm -rf check/in");
						#system("rm -rf check/out");
						#system("rm -rf check/temp");
						#system("rm -rf check");
	 		
	 		}
	 	close(RESULT);
	 	}
	
	sub max{
		my ($a,$b)=@_;
		my $max;
		if($a>=$b){ $max=$a;}
		if($b>$a){ $max=$b;}
		return ($max);
		}
		
	sub min{
		my ($a,$b)=@_;
		my $min;
		if($a<=$b){ $min=$a;}
		if($b<$a){ $min=$b;}
		return ($min);
		}	
