#!/usr/bin/env perl

use strict;
use warnings;
use Cwd 'abs_path';
use File::Basename;
use Getopt::Long;

=head1 Usage

    temphd.pl -r1 <R1.fastq> -r2 <R2.fastq> -f <assembled_file> -id <ID_name> -sp <species_name> -db <bacteria_db>

=head1 Parameters

    -r1  <filename>      file with forward paired-end reads
    -r2  <filename>      file with reverse paired-end reads
    -f   <filename>      file with assembled contigs
    -id  <string>        id name
    -sp  <string>        species name
    -db  <filename>      path of bacteria database
    -h/--help            prints this usage message
    -v/--version         prints version

=head1 Description

    Program: TemPhD  Version: 2.0
    Detecting temperate phage (active prophage) in assembled bacterial genomes 2.0.

=cut


our $R1_fq;
our $R2_fq;
our $Assem_fa;
our $ID;
our $species;
our $nt_Bacteria;
our $help;
our $version;

GetOptions(
    "r1:s"=>\$R1_fq,
    "r2:s"=>\$R2_fq,
    "f:s"=>\$Assem_fa,
    "id:s"=>\$ID,
    "sp:s"=>\$species,
    "db:s"=>\$nt_Bacteria,
    "h|help"=>\$help,
    "v|version"=>\$version,
); 

#die `pod2text $0` if ($help);
#die `pod2text $0` unless ($R1_fq && $R2_fq && $Assem_fa && $ID && $species && $nt_Bacteria);
if ($help) {
    print `pod2text $0`;
    exit;
};
if ($version) {
    print "TemPhD  Version: 2.0\n";
    exit;
};
if (!$R1_fq) {
    print "Error: Missing the -r1 option.\n";
    die `pod2text $0`
};
if (!$R2_fq) {
    print "Error: Missing the -r2 option.\n";
    die `pod2text $0`
};
if (!$Assem_fa) {
    print "Error: Missing the -f option.\n";
    die `pod2text $0`
};
if (!$ID) {
    print "Error: Missing the -id option.\n";
    die `pod2text $0`
};
if (!$species) {
    print "Error: Missing the -sp option.\n";
    die `pod2text $0`
};
if (!$nt_Bacteria) {
    print "Error: Missing the -db option.\n";
    die `pod2text $0`
};

# our $R1_fq = $ARGV[0];
# our $R2_fq = $ARGV[1];
# our $Assem_fa = $ARGV[2];
# our $ID = $ARGV[3];
# our $species = $ARGV[4];
# our $nt_Bacteria = $ARGV[5];

#program path
our $program_path = dirname(abs_path(__FILE__));
#phage database
our $phage_prot_db = "$program_path/phageprot/phageprot.fa";
#bacteria database
#our $nt_Bacteria = "/home/public/database/nt-bac/nt-bac";

our $repeatfind_path = "$program_path/repeatfind.program";

#our $glimmer_path = "$program_path/glimmer3.02/bin";

mkdir "allphages" unless -d "allphages";

system("perl $program_path/find_prophage.rcOnlyN.20210402.pl $R1_fq $R2_fq $Assem_fa $ID $species $phage_prot_db $nt_Bacteria $repeatfind_path $program_path");

print "Analysis Done!\nThe detected phages (if any) are under the folder allphages.\n";

