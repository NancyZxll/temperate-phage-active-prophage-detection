#========================================================================
# Author: XXC
# usage:  perl $phage.fa(extracted sequences, 0) $ctgphgNum(folder path, record the number of sequences on each contig, 1)
# $PossibleSeq (folder path, store the sequences according to contigs, 2) $Matrix (folder path, store the number of sequences on each conig in the format of matrix, 3��

#First, store the sequences on each contig seperately; then, copy them to $ctgphgNum folder. The work of creating the folders of $PossibleSeq��$Matrix will be conduected in the program of the upper layer.
#========================================================================

use strict;
use warnings;
use Cwd;

our $title;
our $flag = 1;
our $count=1;
our $ifallcontig;
our $inputseqpath=$ARGV[0];
our $ctgphgnumpath;
our $possiblepath=$ARGV[2];
our $matrixpath=$ARGV[3];
our $matrixfile;
our $repeatfind_path=$ARGV[4];
our $ctg;
our $seqpath;
our $ctgphgnum;
our $dir=getcwd;
print "!!!!!!!!!in extractphage.pl, the current dir is $dir.!!!!!!!!!\n";

our $contigpath;

if(! -d $ARGV[1]){
	system("mkdir -p $ARGV[1]");
	}
if(! -d $ARGV[2]){
	system("mkdir -p $ARGV[2]");
	}
if(! -d $ARGV[3]){
	system("mkdir -p $ARGV[3]");
	}


if(-s $inputseqpath){
open(SEQ,$ARGV[0]) or die "failed to open:$!";
while(<SEQ>){
	chomp;
	$title=$_;
		$flag += 1;
		
		if(/^>/){
		our @temp = split(/_/,$title);
		print "temp: @temp\n";
	  $ctg=$temp[2];
		if(/^>allcontig/){
			$flag = 0; #find this sequence, set flag as 0, to point to the next sequence.
			$ifallcontig=1;
			#write the output folders of sequence and matrix, if finding it's an idpendent contig
			$ctgphgnumpath=$ARGV[1]."/".$ctg.".txt";
			$seqpath=$possiblepath."/".$ctg.".fa";  #format: contig000w.fa
			$matrixfile=$matrixpath."/".$ctg.".txt"; #The matrix of independent contig will not be used, format: contig000w.txt
			
			print "The ctgphgnumpath is: $ctgphgnumpath\n";
			
			print "The seqname is: $seqpath\n";
			
			open(NUM,">$ctgphgnumpath") or die "failed to open:$!";
			
			print NUM ">$ctg"."_0\n";
			close(NUM);
			}
		else{
		 $flag = 0;
		 $ifallcontig=0;
		 #write the output folders of sequence and matrix, if finding it's a partial contig
		 $seqpath=$possiblepath."/".$ctg."_$count".".fa"; #format: contig000X_1.fa
		 $matrixfile=$matrixpath."/".$ctg."_".$count.".txt"; #format: contig000Y_1.txt
		 print "The seqname is: $seqpath\n";
			}
		$count++;
		}
		$contigpath="$dir/contig/$ctg";
		# flag==1: this line is sequence, not title
		if($flag == 1){
			if($ifallcontig==1){
		#write the seperated files into possibleseq folder
		open(POS,">$seqpath"); 
		print POS $_;
		close(POS);		
		#look for repeats, write the matrix
		print ("Seqpath is: $seqpath\n");
		system("$repeatfind_path/repeatfind $seqpath 13 $matrixfile $contigpath");
	}
	else{
		#write the seperated files into possibleseq folder
		open(POS,">$seqpath"); 
		print POS $_;
		close(POS);		
		#look for repeats, write the matrix
		system("$repeatfind_path/repeatfind $seqpath 13 $matrixfile $contigpath");
		
		}
												 }
			else{
				
				}
			
		
		}
		
		$count-=1;
		if($ifallcontig==0){
			print "111";
			$ctgphgnumpath=$ARGV[1]."/".$ctg.".txt";
			open(NUM,">$ctgphgnumpath") or die "failed to open:$!";
			print NUM "$ctg"."_".$count."\n";
			close(NUM);
			}
}
