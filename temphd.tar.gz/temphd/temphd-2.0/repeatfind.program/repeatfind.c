//usage:  /mount/user/xiexc/temp/repeatfind $�ο�����.fa $minmatch���ظ����е���̳�����ֵ��
//���ڵ�ǰĿ¼������VertedRepeat.fa��InvertedRepeat.fa�����ļ����ֱ�洢�����ظ����кͷ����ظ�����
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <iostream>
#include<fstream>
using namespace std;

#define MAXSIZE 10000
#define AF 0x01
#define CF 0x02
#define GF 0x04
#define TF 0x08
#define FULLFLAG 0x0F
char strUnit[] = {'A', 'C', 'G', 'T'};
unsigned char hGeneFlag;
int maxrepeatlen=0,imebegin=0,imeend=0;
char* imeseq;
char maxrepeat[MAXSIZE / 2 + 1];

int MatchVerted(int MINMATCH, char *strQueue, int nQueueSize) {
ofstream outfile1,fout;
outfile1.open("VertedRepeat.fa");
char *pQueue, strMatch[MAXSIZE / 2 + 1];
int i, nMatchLen, nBegin, nFlag, nPosition;
printf("\nVerted Repeat:\n");
for(nBegin = MINMATCH; nBegin < nQueueSize - MINMATCH; nBegin++) {
pQueue = strQueue + nBegin;
nMatchLen = 0;
nFlag = 0;
hGeneFlag = 0;
for(i = 0; i <= nQueueSize - nBegin; i++) {
if(strQueue[i] == pQueue[i]) {
if(nFlag == 0) {
nFlag = 1;
nPosition = i;
}
switch(strQueue[i]) {
case 'A':
hGeneFlag |= AF;
break;
case 'C':
hGeneFlag |= CF;
break;
case 'G':
hGeneFlag |= GF;
break;
case 'T':
hGeneFlag |= TF;
break;
}
strMatch[nMatchLen++] = strQueue[i];
if(nMatchLen >= nBegin && hGeneFlag == FULLFLAG) {
strMatch[nMatchLen] = 0;
printf("Repeat:%s, Size: %d, Start Positioins:%d, %d\n", strMatch, nMatchLen, nPosition, nPosition + nBegin);
outfile1<<"Repeat: "<<strMatch<<", Size "<<nMatchLen<<", Start Positioins:"<<nPosition<<", "<<pQueue - strQueue + 1<<endl;
nFlag = 0;
nPosition = 0;
nMatchLen = 0;
}
}
else {
if(nFlag == 1) {
if(nMatchLen >= MINMATCH && hGeneFlag == FULLFLAG) {
strMatch[nMatchLen] = 0;
printf("Repeat:%s, Size: %d, Start Positioins:%d, %d\n", strMatch, nMatchLen, nPosition, nPosition + nBegin);
outfile1<<"Repeat: "<<strMatch<<", Size "<<nMatchLen<<", Start Positioins:"<<nPosition<<", "<<pQueue - strQueue + 1<<endl;
}
nFlag = 0;
nPosition = 0;
nMatchLen = 0;
}
}
}
}
outfile1.close();
}

int MatchInverted(int MINMATCH, char *strQueue, int nQueueSize) {
ofstream outfile2,fout;
outfile2.open("InvertedRepeat.fa");
char *pQueue, strMatch[MAXSIZE / 2 + 1];
int i, nMatchLen, nBegin, nFlag, nPosition;
printf("\nInverted Repeat:\n");
for(nBegin = 0; nBegin < nQueueSize - 2 * MINMATCH; nBegin++) {
pQueue = strQueue + nQueueSize - 1 - nBegin;
nMatchLen = 0;
nFlag = 0;
hGeneFlag = 0;
for(i = 0; i < (nQueueSize - nBegin) / 2; i++, pQueue--) {
if(strQueue[i] == *pQueue) {
if(nFlag == 0) {
nFlag = 1;
nPosition = i;
}
switch(strQueue[i]) {
case 'A':
hGeneFlag |= AF;
break;
case 'C':
hGeneFlag |= CF;
break;
case 'G':
hGeneFlag |= GF;
break;
case 'T':
hGeneFlag |= TF;
break;
}
strMatch[nMatchLen++] = strQueue[i];
}
else {
if(nFlag == 1) {
if(nMatchLen >= MINMATCH && hGeneFlag == FULLFLAG) {
strMatch[nMatchLen] = 0;
printf("Repeat:%s, Size: %d, Start Positioins:%d, %d\n", strMatch, nMatchLen, nPosition, pQueue - strQueue + 1);
outfile2<<"Repeat: "<<strMatch<<", Size "<<nMatchLen<<", Start Positioins:"<<nPosition<<", "<<pQueue - strQueue + 1<<endl;
}
nFlag = 0;
nPosition = 0;
nMatchLen = 0;
}
}
}
if(nMatchLen >= MINMATCH && hGeneFlag == FULLFLAG) {
strMatch[nMatchLen] = 0;
printf("Repeat:%s, Size: %d, Start Positioins:%d, %d\n", strMatch, nMatchLen, nPosition, pQueue - strQueue + 1);
outfile2<<"Repeat: "<<strMatch<<", Size "<<nMatchLen<<", Start Positioins:"<<nPosition<<", "<<pQueue - strQueue + 1<<endl;
}
}
outfile2.close();
}

int atoi(char s[]){
	int i,n,sign;
	for(i=0;isspace(s[i]);i++);
	sign=(s[i]=='-')?-1:1;
		if(s[i]=='+'||s[i]=='-')
			i++;
			for(n=0;isdigit(s[i]);i++)
				n=10*n+(s[i]-'0');
				return sign*n;
	
	}


int main(int argc,char** argv ) {
	int minmatch=atoi(argv[2]);
//��ȡ��������
FILE *pFile1=fopen(argv[1],"r");
fseek(pFile1,0,SEEK_END);
int len1=ftell(pFile1);
static char *pBuf1=new char[len1+1];
rewind(pFile1);
fread(pBuf1,1,len1,pFile1);
pBuf1[len1]=0;
printf("The seq1 is:%s\n",pBuf1);
int nQueueSize=strlen(pBuf1);
//�����ظ�����
MatchVerted(minmatch, pBuf1, nQueueSize);
MatchInverted(minmatch, pBuf1, nQueueSize);
fclose(pFile1);
return 0;
}