#!/bin/bash
current_path=$(pwd)

tar -xvf phageprot.tar.gz

makeblastdb -in phageprot/phageprot.fa -dbtype prot -out phageprot/phageprot.fa

echo "export PERL5LIB=$current_path/lib" >> ~/.bashrc

source ~/.bashrc

chmod -R +x ./

ln -s $current_path/temphd.pl ~/bin
