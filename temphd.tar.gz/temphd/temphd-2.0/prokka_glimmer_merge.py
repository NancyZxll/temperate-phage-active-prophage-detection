import sys

rf1=open(sys.argv[1],'r')
rf2=open(sys.argv[2],'r')
wf=open(sys.argv[3],'w')

def func(start, end, ls, le):
    if start < end:
        newend = max(end, le[ls.index(start)])
    else:
        newend = min(end, le[ls.index(start)])
    le.pop(ls.index(start))
    le.insert(ls.index(start), newend)
    return le


#d = {}
ls, le = [], []
for line in rf1:
    ctg = line.split(' ')[1]
    # start = int(line.split(' ')[2])
    # end = int(line.split(' ')[3])
    #d[start] = end
    ls.append(int(line.split(' ')[2]))
    le.append(int(line.split(' ')[3]))

for each in rf2:
    try:
        flag = each.split('\t')[6]
        if flag == '-':
            start = int(each.split('\t')[4])
            end = int(each.split('\t')[3])
        else:
            start = int(each.split('\t')[3])
            end = int(each.split('\t')[4])
        if start in ls and end == le[ls.index(start)]:
            continue
        elif start in ls and end != le[ls.index(start)]:
            le = func(start, end, ls, le)
        elif end in le and start != ls[le.index(end)]:
            ls = func(end, start, le, ls)
        else:
            ls.append(start)
            le.append(end)
    except IndexError:
        continue

k = 1
for i, j in zip(ls, le):
    text = "orf{0} {1} {2} {3}\n".format(str(k).rjust(5, '0'), ctg, i, j)
    wf.write(text)
    k += 1

rf1.close()
rf2.close()
wf.close()