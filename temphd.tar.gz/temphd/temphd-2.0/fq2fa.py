import sys

infile = sys.argv[1]
outfile = sys.argv[2]


f=open(infile,'r')
g=open(outfile,'w')

count = 0
for each in f:
    if count == 0: 
        g.write('>'+each.strip('@'))
    if count == 1:
        g.write(each)
    count +=1
    if count == 4:
        count = 0

f.close()
g.close()
