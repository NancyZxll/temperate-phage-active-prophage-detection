#!/bin/bash

set -e

outdir=$PREFIX/share/$PKG_NAME-$PKG_VERSION-$PKG_BUILDNUM
mkdir -p $outdir
mkdir -p $PREFIX/bin

tar -xvf $SRC_DIR/phageprot.tar.gz
rm -rf $SRC_DIR/phageprot.tar.gz

makeblastdb -in $SRC_DIR/phageprot/phageprot.fa -dbtype prot -out $SRC_DIR/phageprot/phageprot.fa

cp -r $SRC_DIR/* $outdir

echo "export PERL5LIB=$outdir/lib" >> ~/.bashrc

ln -s $outdir/temphd.pl $PREFIX/bin
chmod +x $outdir/repeatfind.program/*
chmod +x $PREFIX/bin/temphd.pl

