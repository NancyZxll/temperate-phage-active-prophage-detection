# function: find potential temperate phage from porphage on a bacterial genome
# usage: perl find_prophage.pl $input.trim.R1.reads $input.trim.R2.reads $input.assembly $input.ID

use strict;
use warnings;
use threads;
use Cwd;

use Tie::File;

my $thread;

my $cwd=getcwd();
our $dir=getcwd;
my $file;
my @dir;
my $dirtemp;
my $flagposition;
my $taglength;
my $assem_seq=$ARGV[2];
our $input_ID = $ARGV[3];
 
# Note!!!!!remember to change it!!!!!
our $program_path = "/mount/user/zhangxll/Projects/Prophage_DB/07.BiologicalExperiments/00.new_program_20190515"; 

print "~.~Notice~.~\nProgram path is:$program_path\n-----------------------\n";

# acquire standard fasta format, first line as title, second line as sequence.
system ("mkdir $program_path/$input_ID.Assembly");
system ("perl $program_path/fa2std.pl $assem_seq $input_ID.Assembly/AllContigs.std");
# reverse-complement sequence, 
#system ("awk 'NR % 2 == 1' $input_ID.Assembly/AllContigs.std > file1.tmp ");
#system ("awk 'NR % 2 == 0' $input_ID.Assembly/AllContigs.std | rev  | tr [ATCG] [TAGC] | tr [atcg] [tagc] > file2.tmp ");
#system ("paste file1.tmp file2.tmp | sed 's/\\t/\\n/g' > $input_ID.Assembly/AllContigs.rc.std"); 
#system ("rm file*.tmp");

# reverse-complement sequence, 
# only consider the sequences with N inside

my $out = '$input_ID.Assembly/ChosenContigs.rc.std';

#open my $out, '>', OUTPUT or die "Cannot open output file: $!";

open (out,">",$out);


tie (my @input, 'Tie::File', '$input_ID.Assembly/AllContigs.std');

for my $linenr (0 .. $#input) {             # loop over line numbers
    if ($input[$linenr] =~ /^>/) {         # this is the current line
        if (index($input[$linenr + 1],"N")!=-1  &&  # this is the next line
            $linenr <= $#input) {           # don't go past end of file
             # do stuff
           print $out $input[$linenr];
           print $out "\n" ;
           print $out $input[$linenr + 1] ;
           print $out "\n";
        }
    }
}
untie @input;   # all done

our $realTime = 0;

# check whether has the rc sequence containing N
if (-e $out){
	$realTime = 2;
	} else {
		$realTime = 1;
		}
		
print "~.~Notice~.~\nThis will run:$realTime time(s)\n-----------------------\n";

# process reads
system ("mkdir $program_path/$input_ID.Reads");
#
system("python $program_path/fq2fa.py $ARGV[0] $program_path/$input_ID.Reads/trim_1P.fa");
system("python $program_path/fq2fa.py $ARGV[1] $program_path/$input_ID.Reads/trim_2P.fa");
system("perl $program_path/handle.pl $input_ID.Reads/trim_1P.fa $input_ID.Reads/handle1.fa 1");
system("perl $program_path/handle.pl $input_ID.Reads/trim_2P.fa $input_ID.Reads/handle2.fa 2");	
system("cat $input_ID.Reads/handle1.fa $input_ID.Reads/handle2.fa > $input_ID.Reads/cat2.fa");


for (my $recordTime=0;$recordTime<$realTime;$recordTime++){
if ($recordTime==0){
open(DATA,"$program_path/$input_ID.Assembly/AllContigs.std");}
elsif ($recordTime==1){
open(DATA,"$program_path/$input_ID.Assembly/ChosenContigs.rc.std");	
	}
our $ok=0;
our $contig;
system("mkdir $program_path/$input_ID.contig");
our $tag;
our $title;
our $count=0;
our @allcontig;
our @lenArray;
our @seqArray;
our $thisSeq;
# record the length
our $count_len = 0;



while(<DATA>){
	chomp;
	next if (/^>/);
	$lenArray[$count_len]= length $_;
	$seqArray[$count_len]=$_;
	$count_len=$count_len+1;
	}
close DATA;

open(Process_DATA,">>$program_path/$input_ID.Assembly/$recordTime.Processed_AllContigs.std");
for (my $loop=0; $loop < scalar @lenArray; $loop++){
print Process_DATA ">contig$loop length=$lenArray[$loop]\n";
print Process_DATA "$seqArray[$loop]\n";	
	}
close Process_DATA;

open(DATA,"$program_path/$input_ID.Assembly/$recordTime.Processed_AllContigs.std");
our $seq_num=0;
while(<DATA>){
	chomp;
	$title=$_;
	# if-else: record the sequences bigger than 10,000bp
	if(/^>/){
		$tag=$title;
		my @temp=split(/\s+/,$title);
		my @temp1=split(/>/,$temp[0]);		
		$contig=$temp1[1];
		print "contig is: $contig\n";

#		if(/length=(\w+)(\s+)/)
#		{ 
#			print "222\n";
#			$len=$1;
#			print "The len is $len\n";
#		}
		my $len = $lenArray[$seq_num];
		$seq_num=$seq_num+1;
		print "The len is $len\n";
		
		if($len>10000){
			$ok=1;
			$allcontig[$count]=$contig;
			$count++;
			print "The contig $contig length is $len\n";
			system("mkdir $program_path/$input_ID.contig/$contig");
			open(CONTIG,">$program_path/$input_ID.contig/$contig/$contig.fa");
			print CONTIG "$tag\n";
			close CONTIG;
			}
		}
	else{
		# if meeting a contig < 10,000 and having contig > 10,000 previously
		if($ok==1){
			open(CONTIG,">>$program_path/$input_ID.contig/$contig/$contig.fa");
			print CONTIG "$title\n";
			system("mkdir $program_path/$input_ID.contig/$contig/in");
			system("mkdir $program_path/$input_ID.contig/$contig/out");
			system("cp $program_path/$input_ID.contig/$contig/$contig.fa $program_path/$input_ID.contig/$contig/in/$contig.fa");
			close CONTIG;					
			$ok=0;
			}
		}
	}
close DATA;


our $i=0;
			system("mkdir $program_path/$input_ID.contig/ctgphgNum");
			system("mkdir $program_path/$input_ID.contig/PossibleSeq");
			system("mkdir $program_path/$input_ID.contig/Matrix");
			system("mkdir $program_path/$input_ID.phage");				
					
			my $part2path;
			
our $j=0;
print "allcontig: @allcontig\n";
print "count is: $count\n";
while(){
	last if($i>=$count);	
		while($i<$count){
		print "i:  $i\n";
		&part2($i);
		$i++;
		}
}

	system("cat $program_path/$input_ID.contig/ctgphgNum/* > $program_path/$input_ID.contig/ctgphgNum.txt");
	
	
#ԭʼ���ݺͲο�������blastn
	system("/mount/user/zhangxll/Softwares/prophage_DB/ncbi-blast-2.2.31+/bin/makeblastdb -in $program_path/$input_ID.Reads/cat2.fa -dbtype nucl -parse_seqids -out $program_path/$input_ID.Reads/read");
	our $name;
	$name = $ARGV[4];#$input_ID;
	system("perl $program_path/prophage_grep.pl $program_path/$input_ID.contig/ctgphgNum.txt $program_path/$input_ID.contig/PossibleSeq $program_path/$input_ID.contig/Matrix $program_path/$input_ID.Reads 1000 $program_path/$input_ID.phage $name $input_ID $program_path $recordTime"); #$allphage_species ");

sub part2(){
	my ($i)=@_;
	$contig=$allcontig[$i];
	print "This is i: $i\n";
	print "This is contig[$i]: $contig\n";
	my $part2path="$input_ID.contig/".$contig."/part2";
	system("perl $program_path/prophageIden-20171030.pl $program_path/$input_ID.contig/$contig/in $program_path/$input_ID.contig/$contig/out $program_path/$input_ID.contig/$contig/temp");
	system("mkdir $program_path/$input_ID.contig/$contig/part2");	
	system("python2 $program_path/blast+2tab-nn+e+2covery.py $program_path/$input_ID.contig/$contig/temp/$contig.fa.blastp $program_path/$input_ID.contig/$contig/temp/$contig.fa.table 1");
	print "~~~~~~~~~~~~~~~~~part2path is $part2path~~~~~~~~~~~~~~~~~\n";
	system("perl $program_path/removefirstline.pl $program_path/$input_ID.contig/$contig/temp/$contig.fa.table $part2path/$contig.table");
	system("perl $program_path/GetPos.pl $program_path/$input_ID.contig/$contig/temp/$contig.fa.txt.title $part2path/Possible1");
	system("perl $program_path/GetPosProtein.pl $part2path/$contig.table $part2path/Possible2");
	system("perl $program_path/fa2std.pl $program_path/$input_ID.contig/$contig/in/$contig.fa $part2path/$contig.std");
	system("cat $part2path/Possible1 $part2path/Possible2 > $part2path/catPossible");
	system("perl $program_path/corange.pl $part2path/catPossible $part2path/coPossible");
	system("perl $program_path/getprophageseqnew.pl $part2path/$contig.std $part2path/coPossible $part2path/prophage.fa");
	system("perl $program_path/extractphage.pl $part2path/prophage.fa $program_path/$input_ID.contig/ctgphgNum $program_path/$input_ID.contig/PossibleSeq $program_path/$input_ID.contig/Matrix");
	}
	
sub checkflag{
	my ($a,$b)=@_;
	my $flagposition;
  my $firstline1;
  my $firstline2;
  my $firstlinenum1;
  my $firstlinenum2;
  my @array1;
  my @array2;
  my $i;
  my $taglength;   #��ʾ���б�־�ĳ���
  open(CHECK1,$a);
  open(CHECK2,$b);
	$firstline1=<CHECK1>;
	$firstline2=<CHECK2>;
	@array1=split //,$firstline1;
	@array2=split //,$firstline2;
	$firstlinenum1=length($firstline1);
	$firstlinenum2=length($firstline2);
	$taglength=$firstlinenum1;
		print "The array1 is: @array1\n";
		print "The array2 is: @array2\n";
		print "The firstlinenum2 is: $firstlinenum2\n";
	for($i=0;$i<$firstlinenum1;$i++){
		print "The array1 array2 is: $array1[$i]  $array2[$i]\n";
			if(($array1[$i] eq "1")&&($array2[$i] eq "2")){
		print "The final array1 array2 is: $array1[$i]  $array2[$i]\n";
				$flagposition=$i;
				}
		}
	print "The inflagpostion is: $flagposition\n";
	return ($flagposition,$taglength);
	}
}


#system("rm -rf $input_ID*");
#print "all detected phages are in the folder of $program_path/allphage.\n Now remove all temporary files...\n All done:)\n";
