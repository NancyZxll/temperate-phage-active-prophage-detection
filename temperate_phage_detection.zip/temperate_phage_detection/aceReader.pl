#========================================================================
# Author: LXY
# Email:  sunqiang55@yahoo.com
# usage:  perl $input $output
#========================================================================

use strict;
use warnings;

open (DATA,"$ARGV[0]") or die "failed to open $ARGV[0]:$!";
open (OUT,">$ARGV[1]");
open (OUT1,">$ARGV[1].tab");
print OUT1 "CONTIG_ID\tPR_CONTIG\tPR_NUM\n";
our @temp;
our @temp1;
our $seq='';
our $ctg_num;
our @ctg_pr;

while(<DATA>){
  chomp;
  $seq = $_;
  if (/^CO/){
  	foreach(1..1000){
  		next if not exists $ctg_pr[$_];
  		if ($ctg_pr[$_] > 10){
  			print OUT1 $ctg_num."\t".$_."\t".$ctg_pr[$_]."\n";
  		}
  	}
  	@temp = split / /, $seq;
  	$ctg_num = $temp[1];
  	foreach(1..1000){
  		$ctg_pr[$_] = 0;
  	}
  }
  if (/^AF/){
  	@temp = split / /, $seq;
  	@temp1 = split /\./, $temp[1];
  	if (/^.*\.pr(\d+) .*$/){
  		$ctg_pr[$1] += 1;
  	}
  	if (@temp1 >= 3){
  		if ($temp1[2] =~ /^pr/){
  			print OUT $temp[0]."\t".$temp1[0].".".$temp1[2]."\t".$temp[2]."\t".$temp[3]."\n";
  		}else{
  			print OUT $seq."\n";
  	  }
  	}else{
  		print OUT $seq."\n";
  	}
  }else{
  	print OUT $seq."\n";
  }
}
close(DATA);
close(OUT);
close(OUT1);