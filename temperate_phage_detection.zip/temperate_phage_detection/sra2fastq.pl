# usage: perl /mount/user/zhaisx/prophage_program sra2fastq.pl allphage_species

use warnings;
use strict;
use Cwd;
use threads;

our $dir=getcwd;
my $file;
my @dirmore;
my @dirall;
my $dirtemp;
my $thread;
my $dirnum;

my $prename1;
my $prename2;
my $subname1;
my $subname2;
my $i=0;
my $iftrimmomatic="yes";
my $ifassembly="yes";

#if(defined $ARGV[0]){
#$iftrimmomatic=$ARGV[0];
#}
#if(defined $ARGV[1]){
#$ifassembly=$ARGV[1];
#}


print "iftrimmomatic  $iftrimmomatic\n";
print "ifassembly   $ifassembly\n";



print "The path is:$dir\n";
#��Ԥ�����������ص����ݷַ��������ļ�����
opendir(DIR,$dir) or die "can't open the directory!";
@dirall=readdir DIR;
@dirall=grep(/[^.]/,@dirall);
print "Currentdir: @dirall\n";
$dirnum=@dirall;
foreach $file(@dirall){	
	$dirtemp=$dir."/".$file;
	print "$dirtemp\n";
	&prehandle($dirtemp,$file);
	}	
close(DIR);


#��ÿ���ļ����е�����ת��Ϊfastq��������
opendir(DIR,$dir) or die "can't open the directory!";
@dirall=readdir DIR;
@dirall=grep(/[^.]/,@dirall);
print "Currentdir: @dirall\n";
$dirnum=@dirall;
foreach $file(@dirall){	
	$dirtemp=$dir."/".$file;
	print "$dirtemp\n";
	chdir($dirtemp);
  &run($dirtemp,$file);
	chdir($dir);
	}	
close(DIR);


sub prehandle(){
	my ($dirtemp,$file)=@_;
	my $name;
	my $infile;
	my $file1;
	my $file2;
	my $temp1;
	my $temp2;
	my $tnum=1;
	my $tempdir=$dirtemp."/Temp";
	my $numlength;
	my $i;
	my @array;
	@array=split(/\./,$file);
	$name=$array[0];
	system("mkdir $name"); 
	system("mv $dirtemp $name"); 
	
	}	
	

sub run(){
	my ($dirtemp,$file)=@_;
	my $name;
	my $infile;
	my $file1;
	my $file2;
	my $temp1;
	my $temp2;
	my $tnum=1;
	my $tempdir=$dirtemp."/Temp";
	my $numlength;
	my $i;
	my @array1;
	my @array2;
	my $sraname=$file.".sra";
	system("pwd");
	print $sraname."\n";
  system("timeout 500 /data/zhaisx/sratoolkit.2.9.2-ubuntu64/bin/fastq-dump --split-3 $sraname");

 	opendir(INDIR,$dirtemp) or die "can't open the directory!";
	my @dir=readdir INDIR;
	@dir=grep(/[^.]/,@dir);
	foreach $infile(@dir){
		if($infile=~/.fastq$/){ 
			if($tnum==1){
				$temp1=$infile;
				$tnum+=1;
				  }
			if($tnum==2){
				$temp2=$infile;
			    }
			}
		}
		
	$numlength=length($temp1);
	@array1=split //,$temp1;
	@array2=split //,$temp2;
	
	if($numlength>2){
	for($i=0;$i<$numlength;$i++){
			if(($array1[$i] eq "1")&&($array2[$i] eq "2")){
				$file1=$temp1;
				$file2=$temp2;
				}
			if(($array1[$i] eq "2")&&($array2[$i] eq "1")){
				$file1=$temp2;
				$file2=$temp1;
				}
		}
	system("gzip $temp1");
	system("gzip $temp2");
	$file1=$file1.".gz";
	$file2=$file2.".gz";
	
	print "111111111111111111111$dirtemp\n$dirtemp/$file1\n$dirtemp/$file2\n";
	mkdir "$tempdir";
	print "Nancy_Check!!!!!!!!!!!!!!!!!!File is: $file\n";
  system("timeout 3600 perl /data/zhaisx/prophage_program/main.pl $file1 $file2 $file $ARGV[0]|tee log.txt");	
}
	close(INDIR);

	
	}	

