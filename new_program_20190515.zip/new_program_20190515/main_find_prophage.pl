
system ("perl find_prophage.pl ");

# reverse-complement
system ("awk 'NR % 2 == 1' $input_ID.Assembly/AllContigs.std > file1.tmp ");
system ("awk 'NR % 2 == 0' $input_ID.Assembly/AllContigs.std | rev  | tr [ATCG] [TAGC] | tr [atcg] [tagc] > file2.tmp ");
system ("paste file1.tmp file2.tmp | sed 's/\\t/\\n/g' > $input_ID.Assembly/AllContigs.rc.std"); 
system ("rm file*.tmp");